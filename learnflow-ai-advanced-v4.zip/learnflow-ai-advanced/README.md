# LearnFlow AI — Advanced AI-free Frontend

A frontend-first, deterministic YouTube transcript-to-course builder. It uses no AI API, no model calls, and no API key.

## Run locally

Node.js 20+ recommended.

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Main routes

- `/` — landing page
- `/dashboard` — learning dashboard
- `/create` — advanced transcript-to-course generator
- `/courses` — sample course library
- `/learn` — sample learning room with lesson navigation, notes and quiz UI
- `/notes` — notes editor
- `/planner` — interactive study planner
- `/roadmaps` — learning roadmaps
- `/explore` — course discovery
- `/achievements` — achievement badges
- `/profile` — profile/settings demo
- `/pricing` — pricing UI

## Rule-based engine

`src/lib/course-engine.ts` implements:
- WebVTT and SRT parsing
- timestamped plain-text parsing
- plain paragraph fallback (estimated timing only)
- caption cue normalization
- multilingual heading phrase patterns (English, Hindi, Bengali)
- token extraction and stop-word filtering
- term-frequency vectors and cosine similarity drift
- topic boundary heuristics
- flexible duration-aware segment merge/split
- title and keyword extraction
- manual lesson split helper
- YouTube chapter-list parser (paste description timestamps; no scraping)
- drag-and-drop lesson ordering and visual topic timeline
- rule-based flashcard and quick-quiz draft extraction from caption sentences

## Added workflow features\n\n- **Chapter extractor:** paste a YouTube description chapter list (one timestamp + title per line). Chapter end times are inferred from the next timestamp; the final chapter receives a 10-minute provisional duration.\n- **Topic timeline:** reorder lessons by dragging their cards; select a segment in the visual timeline to open its editor. Timeline order is a curriculum order and does not rewrite original video timestamps.\n- **Revision kit:** derives flashcard candidates from definition-shaped sentences and quick-quiz prompts from explanatory sentences. This is intentionally conservative and may return few or no items for some transcripts.\n\n## How to use the builder

1. Open `/create`.
2. Paste a YouTube URL (for playback/timestamp links).
3. Import a `.vtt`, `.srt`, `.txt` transcript or paste caption text.
4. Optionally load the sample caption file in the UI.
5. Adjust min/preferred/max lesson durations.
6. Click **Detect topics & build lessons**.
7. Select a lesson and edit title, timestamps, summary and keywords.
8. Reorder, split, delete or add lessons.
9. Use the optional chapter extractor by pasting lines such as `00:00 Introduction` from a video description.
10. Drag lesson cards to reorder the curriculum; the timeline reflects the updated order.
11. Generate draft flashcards and quick-quiz prompts from definition-like / explanatory transcript sentences.
12. Export the editable course and revision kit as JSON.

## Important limitations

- A normal browser cannot reliably fetch captions from arbitrary YouTube URLs because of browser CORS restrictions and YouTube's access controls.
- This frontend deliberately does not scrape captions, download videos, bypass restrictions, or fabricate transcript content.
- Bring a caption file from an authorized source. Caption availability, language, and timestamp quality vary by video.
- Plain transcript fallback estimates timestamps by paragraph order. It is not suitable for accurate timestamp replay.
- Topic detection is heuristic, not semantic AI. It can miss topic changes, over-split repeated terms, or group unrelated material. Always review the generated curriculum.
- The sample transcript is illustrative only and does not correspond to a real video.
- All edits currently live in browser page state and can be exported to JSON; persistent storage/auth/backend are not connected.
- The new revision-kit generator creates heuristic draft prompts from transcript wording. It does not validate facts or guarantee good questions; review every item against the source video. The separate quiz and notes screens remain frontend demonstrations.

## Architecture

The pure TypeScript engine runs client-side. It is deterministic: identical transcript and settings produce the same proposed lesson segmentation. No AI model, OpenRouter, or external generation API is used.

## Cloudflare note

This is a Next.js application. For server-rendered Next.js, use Cloudflare Workers with the OpenNext Cloudflare adapter. A static Pages deployment requires converting the project to a static export and removing server-only features.

import { NextResponse } from "next/server";
import { z } from "zod";

const schema = z.object({ url: z.string().url() });

export async function POST(request: Request) {
  const body = await request.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "A valid YouTube URL is required." }, { status: 400 });
  const host = new URL(parsed.data.url).hostname.replace(/^www\./, "");
  if (!["youtube.com", "m.youtube.com", "youtu.be"].includes(host)) {
    return NextResponse.json({ error: "Only YouTube video and playlist URLs are supported." }, { status: 400 });
  }
  // Transcript acquisition and persistent job queue are intentionally not faked.
  // Add a compliant transcript provider and background job runner before enabling generation.
  if (!process.env.OPENROUTER_API_KEY) {
    return NextResponse.json({ error: "AI generation is not configured yet. Add OPENROUTER_API_KEY and connect a transcript provider." }, { status: 503 });
  }
  return NextResponse.json({
    status: "not_configured",
    message: "AI key detected, but transcript provider and background job queue must be configured before course generation."
  }, { status: 501 });
}

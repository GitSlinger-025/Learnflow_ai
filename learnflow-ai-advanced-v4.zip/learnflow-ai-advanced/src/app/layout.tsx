import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "LearnFlow AI — Turn videos into learning paths",
  description: "Transform educational videos into structured lessons, notes and quizzes."
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}

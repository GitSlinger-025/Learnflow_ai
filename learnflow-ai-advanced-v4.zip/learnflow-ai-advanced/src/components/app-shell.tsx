"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { BookOpen, CalendarDays, Compass, GraduationCap, LayoutDashboard, Map, NotebookPen, Settings, Sparkles, Trophy, PanelLeftClose, Search, Bell } from "lucide-react";
const links = [
  {href:"/dashboard",label:"Overview",icon:LayoutDashboard},
  {href:"/courses",label:"My courses",icon:BookOpen},
  {href:"/planner",label:"Study planner",icon:CalendarDays},
  {href:"/notes",label:"My notes",icon:NotebookPen},
  {href:"/roadmaps",label:"Roadmaps",icon:Map},
  {href:"/explore",label:"Explore",icon:Compass},
  {href:"/achievements",label:"Achievements",icon:Trophy}
];
export function AppShell({children,title="Workspace"}:{children:React.ReactNode;title?:string}) {
 const path=usePathname();
 return <div className="min-h-screen bg-ink text-white">
  <aside className="fixed inset-y-0 left-0 z-30 hidden w-[250px] border-r border-line bg-[#0e1118] px-4 py-5 lg:flex lg:flex-col">
   <Link href="/" className="flex items-center gap-2 px-2 text-lg font-semibold"><span className="grid h-9 w-9 place-items-center rounded-xl bg-accent text-ink"><GraduationCap size={20}/></span>learnflow<span className="text-accent">.ai</span></Link>
   <div className="mt-10 px-3 text-[10px] font-bold tracking-[.2em] text-[#687386]">LEARNING SPACE</div>
   <nav className="mt-3 space-y-1">{links.map(l=>{const active=path===l.href || (l.href==="/courses" && path.startsWith("/courses/"));return <Link key={l.href} href={l.href} className={`flex items-center gap-3 rounded-xl px-3 py-3 text-[13px] transition ${active?"bg-accent/10 text-[#c9c0ff]":"text-muted hover:bg-white/5 hover:text-white"}`}><l.icon size={17}/>{l.label}</Link>})}</nav>
   <div className="mt-auto rounded-2xl border border-accent/20 bg-gradient-to-br from-accent/10 to-panel p-4"><div className="flex items-center gap-2 text-sm font-semibold"><Sparkles size={15} className="text-accent"/> Your plan</div><p className="mt-2 text-xs leading-5 text-muted">Starter · 1 of 5 build hours used</p><div className="mt-3 h-1.5 rounded-full bg-white/10"><div className="h-full w-1/5 rounded-full bg-accent"/></div><Link href="/pricing" className="mt-4 block text-xs font-semibold text-[#c9c0ff]">Explore plans →</Link></div>
   <Link href="/profile" className="mt-4 flex items-center gap-3 rounded-xl px-2 py-3 hover:bg-white/5"><span className="grid h-9 w-9 place-items-center rounded-full bg-[#292342] text-xs font-bold text-[#d6ceff]">SR</span><span className="min-w-0 flex-1"><span className="block text-xs font-semibold">Srijan</span><span className="block text-[10px] text-muted">Free workspace</span></span><Settings size={15} className="text-muted"/></Link>
  </aside>
  <div className="lg:pl-[250px]">
   <header className="sticky top-0 z-20 flex h-[68px] items-center justify-between border-b border-line bg-ink/90 px-5 backdrop-blur-xl md:px-8">
    <div><p className="text-[10px] text-muted">LEARNFLOW / {title.toUpperCase()}</p><p className="mt-1 text-sm font-semibold">{title}</p></div>
    <div className="flex items-center gap-2"><button className="grid h-9 w-9 place-items-center rounded-xl border border-line text-muted hover:text-white"><Search size={16}/></button><button className="relative grid h-9 w-9 place-items-center rounded-xl border border-line text-muted hover:text-white"><Bell size={16}/><i className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-accent"/></button><Link href="/profile" className="ml-1 grid h-9 w-9 place-items-center rounded-full bg-accent/20 text-xs font-bold text-[#d6ceff]">SR</Link></div>
   </header>
   <main className="mx-auto max-w-[1440px] p-5 md:p-8">{children}</main>
  </div>
  <nav className="fixed bottom-0 left-0 right-0 z-40 grid grid-cols-5 border-t border-line bg-[#0e1118]/95 px-2 py-2 backdrop-blur lg:hidden">{[{href:"/dashboard",label:"Home",icon:LayoutDashboard},{href:"/courses",label:"Courses",icon:BookOpen},{href:"/planner",label:"Planner",icon:CalendarDays},{href:"/notes",label:"Notes",icon:NotebookPen},{href:"/profile",label:"Profile",icon:Settings}].map(l=><Link key={l.href} href={l.href} className={`flex flex-col items-center gap-1 py-1 text-[9px] ${path===l.href?"text-accent":"text-muted"}`}><l.icon size={17}/>{l.label}</Link>)}</nav>
 </div>
}

import Link from "next/link";
import { ArrowUpRight, GraduationCap } from "lucide-react";
export function Nav() {
  return <header className="sticky top-0 z-50 border-b border-line/80 bg-ink/85 backdrop-blur-xl">
    <div className="container flex h-[72px] items-center justify-between">
      <Link href="/" className="flex items-center gap-2 text-lg font-semibold tracking-tight"><span className="grid h-9 w-9 place-items-center rounded-xl bg-accent text-ink"><GraduationCap size={21}/></span>learnflow<span className="text-accent">.ai</span></Link>
      <nav className="hidden items-center gap-8 text-sm text-muted md:flex"><a href="#features" className="hover:text-white">Features</a><Link href="/courses" className="hover:text-white">Explore</Link><a href="#pricing" className="hover:text-white">Pricing</a></nav>
      <div className="flex items-center gap-3"><Link href="/dashboard" className="hidden text-sm text-muted hover:text-white sm:block">Log in</Link><Link href="/dashboard" className="flex items-center gap-2 rounded-xl bg-white px-4 py-2.5 text-sm font-semibold text-ink transition hover:bg-accent">Start learning <ArrowUpRight size={16}/></Link></div>
    </div>
  </header>;
}

/**
 * Deterministic, AI-free transcript-to-course engine.
 * Uses caption timestamps, heading cues, multilingual lexical signals,
 * TF-IDF-like term vectors, lexical drift, and duration-aware segmentation.
 *
 * Accuracy depends on transcript quality. The engine proposes editable chapters;
 * it does not claim human-level semantic understanding.
 */
export type TranscriptCue = { start: number; end: number; text: string };
export type Lesson = {
  id: string;
  title: string;
  start: number;
  end: number;
  duration: number;
  summary: string;
  keywords: string[];
  confidence: number;
  sourceCueCount: number;
  manuallyEdited?: boolean;
};
export type EngineOptions = {
  minMinutes?: number;
  maxMinutes?: number;
  preferredMinutes?: number;
  language?: "both" | "english" | "hindi" | "bengali";
};
export type EngineResult = {
  lessons: Lesson[];
  cues: TranscriptCue[];
  stats: { cueCount: number; wordCount: number; duration: number; detectedBoundaries: number };
  warnings: string[];
};

const STOP = new Set((
  "the a an and or but if then so to of in on at for from with by is are was were be been being it this that these those as into about over under after before than also very can could should would will may might do does did have has had i you he she we they them their our your my me us what which who when where why how there here not no yes".split(" ")
).concat([
  "और", "या", "है", "हैं", "था", "थे", "थी", "को", "का", "की", "के", "में", "से", "पर", "एक", "यह", "वह", "इस", "उस", "जो", "कि", "तो", "भी", "कर", "करें", "हो", "होता", "होती", "होने", "आप", "हम", "मैं",
  "এবং", "আর", "অথবা", "হয়", "হয়", "হচ্ছে", "করে", "করতে", "এর", "এই", "ওই", "একটি", "একটা", "থেকে", "জন্য", "কিন্তু", "যে", "কি", "কী", "আপনি", "আমি", "আমরা"
]));
const HEADING_PATTERNS = [
  /(?:^|\b)(?:chapter|section|part|module|lesson|topic)\s*(?:\d+|[ivx]+)?\s*[:.\-–—]\s*/i,
  /(?:^|\b)(?:welcome to|let'?s (?:talk|learn|understand|start)|today we(?:'| wi)ll|in this (?:video|lesson|section)|moving on to|next topic|now let'?s|firstly|secondly)\b/i,
  /(?:^|\b)(?:introduction|overview|definition|examples?|summary|conclusion|recap|practice|exercise|installation|setup|syntax|variables?|functions?|loops?|arrays?|classes|objects?|database|query|operators?|conditional statements?)\s*[:\-–—]/i,
  /(?:अब|अगला विषय|चलिए|आइए|परिचय|उदाहरण|निष्कर्ष|अब बात करते हैं)/,
  /(?:এবার|পরের বিষয়|পরবর্তী বিষয়|চলুন|ভূমিকা|উদাহরণ|উপসংহার|এখন আলোচনা করি)/,
  /^(?:intro(?:duction)?|overview|basics|fundamentals|setup|installation|variables?|data types?|operators?|expressions?|conditions?|conditional statements?|loops?|iteration|functions?|modules?|classes|objects?|arrays?|strings?|databases?|queries?|joins?|examples?|practice|exercise|summary|conclusion|recap)\s*$/i,
  /^(?:परिचय|मूल बातें|स्थापना|वेरिएबल|डेटा टाइप|ऑपरेटर|शर्तें|लूप|फंक्शन|मॉड्यूल|उदाहरण|अभ्यास|सारांश|निष्कर्ष)\s*$/,
  /^(?:ভূমিকা|মৌলিক বিষয়|ইনস্টলেশন|ভেরিয়েবল|ডেটা টাইপ|অপারেটর|শর্ত|লুপ|ফাংশন|মডিউল|উদাহরণ|অনুশীলন|সারাংশ|উপসংহার)\s*$/
];
const TOPIC_CUES = [
  "introduction","overview","definition","basics","fundamentals","example","examples","types","features","advantages","disadvantages","installation","setup","syntax","variable","variables","data type","operator","operators","condition","loop","loops","function","functions","class","classes","object","objects","array","arrays","string","strings","database","query","queries","join","joins","select","insert","update","delete","recursion","algorithm","practice","exercise","summary","conclusion","recap",
  "परिचय","उदाहरण","प्रकार","विशेषता","स्थापना","वेरिएबल","डेटा टाइप","लूप","फंक्शन","क्लास","ऑब्जेक्ट","सारांश","निष्कर्ष",
  "ভূমিকা","উদাহরণ","ধরন","বৈশিষ্ট্য","ইনস্টল","ভেরিয়েবল","ডেটা টাইপ","লুপ","ফাংশন","ক্লাস","অবজেক্ট","সারাংশ","উপসংহার"
];

function cleanText(s: string) {
  return s.replace(/<[^>]*>/g, " ").replace(/&nbsp;/g, " ").replace(/\s+/g, " ").trim();
}
function parseClock(raw: string): number | null {
  const s = raw.trim().replace(",", ".");
  const parts = s.split(":");
  if (parts.length < 2 || parts.length > 3) return null;
  const nums = parts.map(Number);
  if (nums.some(n => !Number.isFinite(n))) return null;
  if (parts.length === 3) return nums[0]*3600 + nums[1]*60 + nums[2];
  return nums[0]*60 + nums[1];
}
export function parseTranscript(raw: string): TranscriptCue[] {
  const text = raw.replace(/\r/g, "").trim();
  if (!text) return [];
  const cues: TranscriptCue[] = [];
  // WebVTT and SRT timestamp lines.
  const timeLine = /(\d{1,2}:)?\d{2}:\d{2}[.,]\d{3}\s*-->\s*(\d{1,2}:)?\d{2}:\d{2}[.,]\d{3}/;
  const blocks = text.split(/\n\s*\n/);
  for (const block of blocks) {
    const lines = block.split("\n").map(x=>x.trim()).filter(Boolean);
    const idx = lines.findIndex(x=>timeLine.test(x));
    if (idx < 0) continue;
    const m = lines[idx].match(/((?:\d{1,2}:)?\d{2}:\d{2}[.,]\d{3})\s*-->\s*((?:\d{1,2}:)?\d{2}:\d{2}[.,]\d{3})/);
    if (!m) continue;
    const start=parseClock(m[1]), end=parseClock(m[2]);
    const cueText=cleanText(lines.slice(idx+1).join(" "));
    if (start !== null && end !== null && end > start && cueText) cues.push({start,end,text:cueText});
  }
  if (cues.length) return dedupeCues(cues);
  // Plain transcript format: [00:00:03] words... or 00:00:03 words...
  const lines=text.split("\n");
  for (const line of lines) {
    const m=line.match(/^\s*\[?((?:\d{1,2}:)?\d{1,2}:\d{2}(?:[.,]\d{1,3})?)\]?\s*[-–—:]?\s+(.+)$/);
    if (!m) continue;
    const start=parseClock(m[1]);
    const body=cleanText(m[2]);
    if (start!==null && body) cues.push({start,end:start+5,text:body});
  }
  if (cues.length) {
    cues.sort((a,b)=>a.start-b.start);
    return cues.map((c,i)=>({...c,end:Math.max(c.end,cues[i+1]?.start ?? c.end+5)}));
  }
  // Plain text fallback: keep text usable, but no fabricated fine-grained timestamps.
  const paragraphs=text.split(/\n{2,}/).map(cleanText).filter(Boolean);
  const chunks=paragraphs.length ? paragraphs : [cleanText(text)];
  return chunks.map((t,i)=>({start:i*60,end:(i+1)*60,text:t}));
}
function dedupeCues(cues: TranscriptCue[]) {
  const sorted=cues.sort((a,b)=>a.start-b.start);
  const out:TranscriptCue[]=[];
  for(const c of sorted) {
    const prev=out[out.length-1];
    if(prev && c.start<prev.end && c.text.toLowerCase()===prev.text.toLowerCase()) continue;
    out.push(c);
  }
  return out;
}
function tokens(text:string) {
  return (text.toLocaleLowerCase().match(/[\p{L}\p{N}][\p{L}\p{N}_+#.-]*/gu)||[])
    .map(x=>x.replace(/^[^a-z0-9\u0900-\u097f\u0980-\u09ff]+|[^a-z0-9\u0900-\u097f\u0980-\u09ff+#]+$/giu,""))
    .filter(x=>x.length>2&&!STOP.has(x)&&!/^(\d+|www|http)$/.test(x));
}
function vector(text:string) {
  const counts=new Map<string,number>();
  for(const t of tokens(text)) counts.set(t,(counts.get(t)||0)+1);
  const total=[...counts.values()].reduce((a,b)=>a+b,0)||1;
  return new Map([...counts].map(([k,v])=>[k,v/total]));
}
function similarity(a:Map<string,number>,b:Map<string,number>) {
  let dot=0,aa=0,bb=0;
  for(const v of a.values()) aa+=v*v;
  for(const v of b.values()) bb+=v*v;
  for(const [k,v] of a) dot+=v*(b.get(k)||0);
  return aa&&bb?dot/Math.sqrt(aa*bb):0;
}
function topTerms(text:string, limit=5) {
  const counts=new Map<string,number>();
  tokens(text).forEach(t=>counts.set(t,(counts.get(t)||0)+1));
  return [...counts].sort((a,b)=>b[1]-a[1]).slice(0,limit).map(x=>x[0]);
}
function sentenceLike(text:string) {
  return text.split(/(?<=[.!?।॥])\s+|(?<=[。！？])\s*/).map(cleanText).filter(Boolean);
}
function hasHeading(text:string) {
  return HEADING_PATTERNS.some(p=>p.test(text));
}
function headingTitle(text:string) {
  let t=cleanText(text);
  t=t.replace(/^(?:chapter|section|part|module|lesson|topic)\s*(?:\d+|[ivx]+)?\s*[:.\-–—]\s*/i,"");
  t=t.replace(/^(?:welcome to|let'?s (?:talk|learn|understand|start)|today we(?:'| wi)ll|in this (?:video|lesson|section)|moving on to|next topic|now let'?s)\s*/i,"");
  return t.split(/[.!?।॥]/)[0].slice(0,72).trim();
}
function formatTitle(cues:TranscriptCue[], index:number) {
  const joined=cues.map(c=>c.text).join(" ");
  const headings=cues.filter(c=>hasHeading(c.text)).map(c=>headingTitle(c.text)).filter(x=>x.length>3);
  if(headings.length) return headings[0].replace(/^\w/,x=>x.toUpperCase());
  const terms=topTerms(joined,3);
  if(terms.length) return terms.map(x=>x.charAt(0).toUpperCase()+x.slice(1)).join(" & ");
  return `Learning section ${index+1}`;
}
function buildSegments(cues:TranscriptCue[], opts:EngineOptions) {
  const min=(opts.minMinutes??5)*60, max=(opts.maxMinutes??28)*60, preferred=(opts.preferredMinutes??16)*60;
  const segments:{cues:TranscriptCue[];score:number}[]=[];
  let current:TranscriptCue[]=[];
  let currentText="";
  let currentVec=vector("");
  for(let i=0;i<cues.length;i++) {
    const cue=cues[i];
    const nextText=currentText+" "+cue.text;
    const nextVec=vector(nextText);
    const elapsed=current.length?cue.end-current[0].start:cue.end-cue.start;
    const prevCue=current[current.length-1];
    const gap=prevCue?cue.start-prevCue.end:0;
    const cueIsHeading=hasHeading(cue.text);
    const previousVec= current.length ? vector(current.slice(-3).map(x=>x.text).join(" ")) : new Map<string,number>();
    const drift=current.length?1-similarity(previousVec,vector(cue.text)):0;
    const topicCue=TOPIC_CUES.some(k=>cue.text.toLowerCase().includes(k));
    const naturalBreak=current.length>0 && (
      (cueIsHeading && elapsed>=min*0.55) ||
      (gap>=12 && elapsed>=min) ||
      (elapsed>=max) ||
      (elapsed>=min && drift>0.78 && topicCue) ||
      (elapsed>=preferred*1.35 && drift>0.62)
    );
    if(naturalBreak) {
      segments.push({cues:current,score:Math.min(0.98,0.55+drift*0.35+(cueIsHeading?0.12:0))});
      current=[]; currentText=""; currentVec=vector("");
    }
    current.push(cue); currentText+=" "+cue.text; currentVec=nextVec;
  }
  if(current.length) segments.push({cues:current,score:0.66});
  // Merge very short adjacent fragments unless a strong explicit heading separates them.
  for(let i=0;i<segments.length-1;) {
    const a=segments[i],b=segments[i+1];
    const dur=a.cues[a.cues.length-1].end-a.cues[0].start;
    const boundaryHeading=hasHeading(b.cues[0].text);
    if(dur<min*0.55&&!boundaryHeading) {
      a.cues=[...a.cues,...b.cues]; a.score=Math.min(a.score,b.score); segments.splice(i+1,1);
    } else i++;
  }
  // Split overlong chunks near sentence boundaries / cue boundaries.
  const split:typeof segments=[];
  for(const seg of segments) {
    let bucket:TranscriptCue[]=[];
    for(const cue of seg.cues) {
      if(bucket.length && cue.end-bucket[0].start>max && bucket.length>=2) {
        split.push({cues:bucket,score:seg.score*0.92}); bucket=[];
      }
      bucket.push(cue);
    }
    if(bucket.length) split.push({cues:bucket,score:seg.score});
  }
  return split;
}
export function generateCourse(raw:string, options:EngineOptions={}):EngineResult {
  const cues=parseTranscript(raw);
  const warnings:string[]=[];
  if(!cues.length) return {lessons:[],cues,stats:{cueCount:0,wordCount:0,duration:0,detectedBoundaries:0},warnings:["No transcript text was found. Paste a WebVTT, SRT, timestamped transcript, or plain text."]};
  const segments=buildSegments(cues,options);
  const lessons:Lesson[]=segments.map((s,i)=>{
    const text=s.cues.map(c=>c.text).join(" ");
    const start=s.cues[0].start, end=s.cues[s.cues.length-1].end;
    const sentences=sentenceLike(text);
    const summary=sentences.slice(0,2).join(" ").slice(0,260) || text.slice(0,260);
    return {id:`lesson-${i+1}-${Math.round(start)}`,title:formatTitle(s.cues,i),start,end,duration:Math.max(0,end-start),summary,keywords:topTerms(text,6),confidence:s.score,sourceCueCount:s.cues.length};
  });
  const words=cues.reduce((n,c)=>n+tokens(c.text).length,0);
  if(cues.length<8) warnings.push("Very few caption segments were supplied; topic boundaries may be rough.");
  if(!cues.some(c=>/\d{1,2}:\d{2}/.test(c.text)) && raw.split("\n").length<4) warnings.push("Transcript appears to be plain text. Timestamps are estimated from paragraph order; import timestamped captions for accurate timing.");
  if(lessons.length===1) warnings.push("Only one section was detected. Try a timestamped transcript with clearer chapter cues, or add/split topics manually.");
  return {lessons,cues,stats:{cueCount:cues.length,wordCount:words,duration:cues[cues.length-1].end,detectedBoundaries:Math.max(0,lessons.length-1)},warnings};
}
export function secondsToClock(value:number) {
  const s=Math.max(0,Math.floor(value));
  const h=Math.floor(s/3600),m=Math.floor((s%3600)/60),sec=s%60;
  return h?`${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}:${String(sec).padStart(2,"0")}`:`${String(m).padStart(2,"0")}:${String(sec).padStart(2,"0")}`;
}
export function clockToSeconds(value:string) {
  const p=value.trim().split(":").map(Number);
  if(p.some(x=>!Number.isFinite(x)||x<0)) return null;
  if(p.length===3) return p[0]*3600+p[1]*60+p[2];
  if(p.length===2) return p[0]*60+p[1];
  return null;
}
export function splitLesson(lesson:Lesson, cues:TranscriptCue[]):Lesson[] {
  const inside=cues.filter(c=>c.start>=lesson.start&&c.end<=lesson.end);
  if(inside.length<2) return [];
  const midpoint=Math.floor(inside.length/2);
  const left=inside.slice(0,midpoint),right=inside.slice(midpoint);
  const make=(list:TranscriptCue[],suffix:string):Lesson=>{
    const text=list.map(c=>c.text).join(" ");
    return {...lesson,id:`${lesson.id}-${suffix}`,title:formatTitle(list,0),start:list[0].start,end:list[list.length-1].end,duration:list[list.length-1].end-list[0].start,summary:sentenceLike(text).slice(0,2).join(" ").slice(0,260),keywords:topTerms(text,6),sourceCueCount:list.length,manuallyEdited:true};
  };
  return left.length&&right.length?[make(left,"a"),make(right,"b")]:[];
}


export type LearningAsset = { question: string; answer: string; source: string };
export function parseYouTubeChapters(raw: string): Lesson[] {
  const rows = raw.replace(/\r/g, "").split("\n").map(x => x.trim()).filter(Boolean);
  const found: { time: number; title: string }[] = [];
  for (const row of rows) {
    const m = row.match(/^\s*(?:(\d{1,2}:)?(\d{1,2}):(\d{2}))\s+[-–—|:]?\s*(.+?)\s*$/);
    if (!m) continue;
    const h = m[1] ? Number(m[1].slice(0, -1)) : 0;
    const mm = Number(m[2]), ss = Number(m[3]);
    if (mm > 59 || ss > 59) continue;
    const time = h * 3600 + mm * 60 + ss;
    const title = m[4].replace(/^[-–—|:]\s*/, "").trim();
    if (title && (!found.length || time > found[found.length - 1].time)) found.push({ time, title });
  }
  return found.map((x, i) => {
    const end = found[i + 1]?.time ?? x.time + 600;
    return { id: `chapter-${i + 1}-${x.time}`, title: x.title, start: x.time, end, duration: end - x.time,
      summary: `Imported from the YouTube chapter list: ${x.title}`, keywords: topTerms(x.title, 5),
      confidence: 1, sourceCueCount: 0, manuallyEdited: true };
  });
}
export function generateLearningAssets(cues: TranscriptCue[]): { flashcards: LearningAsset[]; quiz: LearningAsset[] } {
  const sentences = cues.flatMap(c => sentenceLike(c.text).map(sentence => ({ sentence, source: secondsToClock(c.start) })));
  const useful = sentences.filter(x => x.sentence.length >= 35 && x.sentence.length <= 260);
  const flashcards: LearningAsset[] = [];
  const quiz: LearningAsset[] = [];
  const seen = new Set<string>();
  for (const item of useful) {
    const sentence = item.sentence.replace(/\s+/g, " ").trim();
    const definition = sentence.match(/^(.{2,65}?)\s+(?:is|are|means|refers to|is called|হলো|হয়|হয়|বলতে বোঝায়|कहलाता है|है)\s+(.{8,180})$/i);
    if (definition) {
      const q = `What is ${definition[1].trim()}?`;
      if (!seen.has(q.toLowerCase())) {
        flashcards.push({ question: q, answer: definition[2].replace(/[.!?।॥]+$/, ""), source: item.source });
        seen.add(q.toLowerCase());
      }
    }
    if (/\b(?:because|therefore|for example|such as|include|consists of|allows|used to|helps|means|refers to)\b|হলো|কারণ|যেমন|ব্যবহার করা হয়|क्योंकि|उदाहरण|उपयोग/i.test(sentence)) {
      const question = `Complete the idea: ${sentence.slice(0, Math.min(90, Math.floor(sentence.length * 0.55)))}…`;
      if (!seen.has(question.toLowerCase())) {
        quiz.push({ question, answer: sentence, source: item.source });
        seen.add(question.toLowerCase());
      }
    }
    if (flashcards.length >= 20 && quiz.length >= 20) break;
  }
  return { flashcards: flashcards.slice(0, 20), quiz: quiz.slice(0, 20) };
}

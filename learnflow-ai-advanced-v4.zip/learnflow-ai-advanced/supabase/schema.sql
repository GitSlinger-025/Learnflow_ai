-- LearnFlow AI starter schema. Apply in Supabase SQL editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  avatar_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.courses (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid references auth.users(id) on delete cascade,
  title text not null,
  description text,
  source_url text not null,
  source_video_id text,
  visibility text not null default 'private' check (visibility in ('private','public')),
  status text not null default 'draft' check (status in ('draft','queued','processing','ready','failed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.lessons (
  id uuid primary key default gen_random_uuid(),
  course_id uuid not null references public.courses(id) on delete cascade,
  title text not null,
  summary text,
  content_md text,
  start_seconds integer,
  end_seconds integer,
  position integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.lesson_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  lesson_id uuid not null references public.lessons(id) on delete cascade,
  completed_at timestamptz,
  updated_at timestamptz not null default now(),
  primary key (user_id, lesson_id)
);

create table if not exists public.notes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  lesson_id uuid references public.lessons(id) on delete cascade,
  body text not null,
  timestamp_seconds integer,
  created_at timestamptz not null default now()
);

create table if not exists public.quizzes (
  id uuid primary key default gen_random_uuid(),
  lesson_id uuid not null references public.lessons(id) on delete cascade,
  title text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.quiz_questions (
  id uuid primary key default gen_random_uuid(),
  quiz_id uuid not null references public.quizzes(id) on delete cascade,
  prompt text not null,
  options jsonb not null,
  correct_index integer not null,
  explanation text,
  timestamp_seconds integer,
  position integer not null default 0
);

create table if not exists public.quiz_attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  quiz_id uuid not null references public.quizzes(id) on delete cascade,
  score integer not null,
  answers jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.courses enable row level security;
alter table public.lessons enable row level security;
alter table public.lesson_progress enable row level security;
alter table public.notes enable row level security;
alter table public.quizzes enable row level security;
alter table public.quiz_questions enable row level security;
alter table public.quiz_attempts enable row level security;

create policy "profiles own row" on public.profiles for all using (auth.uid() = id) with check (auth.uid() = id);
create policy "course owner access" on public.courses for all using (auth.uid() = owner_id or visibility = 'public') with check (auth.uid() = owner_id);
create policy "lessons readable for visible courses" on public.lessons for select using (
  exists (select 1 from public.courses c where c.id = course_id and (c.owner_id = auth.uid() or c.visibility = 'public'))
);
create policy "lesson owner writes" on public.lessons for all using (
  exists (select 1 from public.courses c where c.id = course_id and c.owner_id = auth.uid())
) with check (
  exists (select 1 from public.courses c where c.id = course_id and c.owner_id = auth.uid())
);
create policy "progress own rows" on public.lesson_progress for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "notes own rows" on public.notes for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "quiz readable for visible lessons" on public.quizzes for select using (
  exists (select 1 from public.lessons l join public.courses c on c.id=l.course_id where l.id=lesson_id and (c.owner_id=auth.uid() or c.visibility='public'))
);
create policy "questions readable" on public.quiz_questions for select using (
  exists (select 1 from public.quizzes q join public.lessons l on l.id=q.lesson_id join public.courses c on c.id=l.course_id where q.id=quiz_id and (c.owner_id=auth.uid() or c.visibility='public'))
);
create policy "attempts own rows" on public.quiz_attempts for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

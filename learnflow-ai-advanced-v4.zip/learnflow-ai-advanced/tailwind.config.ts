import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: { extend: { colors: { ink: "#0b0d12", panel: "#121620", line: "#252b38", muted: "#929bad", accent: "#9b8cff" }, boxShadow: { glow: "0 0 50px rgba(155,140,255,.16)" } } },
  plugins: []
};
export default config;
